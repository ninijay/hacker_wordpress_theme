</div><!-- /.row -->

</div><!-- /.container -->
<div class="container">
    <footer class="blog-footer">
        <?php if ( is_active_sidebar( 'footer-copyright-text' ) ) { dynamic_sidebar( 'footer-copyright-text' ); } ?>
    </footer>
    <?php wp_footer(); ?>
</div>
</body>
</html>
